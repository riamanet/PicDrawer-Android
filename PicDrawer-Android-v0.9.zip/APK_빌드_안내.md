# 픽서랍 v0.9 APK 설치 안내

기존 GitHub 저장소: https://github.com/riamanet/PicDrawer-Android

1. 저장소에서 Add file → Upload files 를 눌러 `PicDrawer-Android-v0.9.zip`을 업로드합니다.
2. `.github/workflows/build-apk.yml`은 최신 `PicDrawer-Android-v*.zip`을 선택하도록 설정되어 있습니다. 현재 GitHub의 설정이 그 버전일 경우 별도로 수정하지 않아도 됩니다.
3. Actions에서 `Build PicDrawer APK`의 가장 최근 실행을 확인하고 완료 상태가 성공인지 확인합니다.
4. 현 GitHub 워크플로의 이름이 v0.8로 되어 있어도 **최신 v0.9 ZIP을 빌드**합니다. Artifacts에서 `PicDrawer-v0.8-APK` ZIP을 내려받아 압축 해제하고 `app-debug.apk`를 설치합니다.

빌드 파일 작성 권한이 연결된 GitHub 커넥터에는 없어 사용자가 업로드해야 합니다. v0.9 프로젝트는 이 작업 환경에서 Java 그룹 테스트를 통과했지만 Android APK 빌드 및 단말 검증은 아직 하지 않았습니다.

안전 참고: 기존과 동일 앱 ID/디버그 서명으로 업데이트를 의도했습니다. 사진을 삭제하거나 실제 앨범으로 이동하는 기능은 테스트용 사진에서만 먼저 사용하세요. 얼굴의 단순 질감과 사진 간 근접성은 정확한 신원 인식이 아니며, 다른 날짜에 찍힌 같은 사람은 미분류로 남을 수 있습니다.
