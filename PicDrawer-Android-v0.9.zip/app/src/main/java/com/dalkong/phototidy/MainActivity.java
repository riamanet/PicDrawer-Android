package com.dalkong.phototidy;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.res.ColorStateList;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Initial runnable Android prototype: user chooses albums, local analysis,
 *  review suggestions, and OS-confirmed trash. No cloud and no auto deletion. */
public final class MainActivity extends Activity {
    private static final int REQ_PERMISSION = 110;
    private static final int REQ_TRASH = 111;
    private static final int REQ_MOVE = 112;
    private static final int BG = Color.rgb(14,17,24);
    private static final int SURFACE = Color.rgb(28,34,47);
    private static final int FOREGROUND = Color.rgb(239,243,251);
    private static final int MUTED = Color.rgb(161,175,193);
    private static final int ACCENT = Color.rgb(164,198,255);
    private static final int RED = Color.rgb(255,170,171);

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancel = new AtomicBoolean(false);
    private final Set<String> selectedAlbums = new HashSet<>();
    private final Set<Long> deleteSelection = new HashSet<>();
    /** A trash request may contain only a bounded number of URIs.
     *  The user approves each chunk in the Android system confirmation UI. */
    private final Set<Long> pendingTrashIds = new HashSet<>();
    private static final int MAX_TRASH_BATCH = 100;
    private static final int MAX_MOVE_BATCH = 500;
    private final Set<String> selectedMoveTargets = new LinkedHashSet<>();
    private final Set<Long> movedInSession = new HashSet<>();
    private final List<AlbumMove> pendingMoveBatch = new ArrayList<>();
    private boolean movePlanInitialized = false;
    private static final String PHOTO_FOLDER = "Pictures/픽서랍/";
    private static final class AlbumMove {
        final PhotoInfo photo;
        final String path;
        AlbumMove(PhotoInfo photo, String path) { this.photo=photo; this.path=path; }
    }
    private String returnFromReview = "results";
    private final Set<Long> personEditSelection = new HashSet<>();
    private final Map<Integer,Long> chosenKeep = new HashMap<>();
    private boolean personEditMode = false;
    private boolean unclassifiedAssignMode = false;
    private int compareScrollX=0;
    private PersonOverrides personOverrides;

    private PhotoRepository repository;
    private Thumbs thumbs;
    private List<PhotoInfo> library = new ArrayList<>();
    private List<PhotoInfo> scanned = new ArrayList<>();
    private Map<String,List<PhotoInfo>> albums = new LinkedHashMap<>();
    private Groups result;
    private String currentCategory = "people";
    private long currentPerson = -1;
    private int currentSimilar = -1;
    private String currentScreen = "albums";
    private TextView progressLabel;
    private ProgressBar progressBar;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        repository = new PhotoRepository(this);
        personOverrides = new PersonOverrides(this);
        thumbs = new Thumbs(this);
        if (hasPhotoAccess()) loadAlbums(); else showPermission();
    }

    private boolean hasPhotoAccess() {
        if (Build.VERSION.SDK_INT >= 33)
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    || (Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED);
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean partialAccess() {
        return Build.VERSION.SDK_INT >= 34
                && checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPhotoAccess() {
        if (Build.VERSION.SDK_INT >= 34)
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQ_PERMISSION);
        else if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PERMISSION);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if (requestCode == REQ_PERMISSION) {
            if (hasPhotoAccess()) loadAlbums(); else showPermission();
        }
    }

    private int dp(float dp) { return Math.round(dp * getResources().getDisplayMetrics().density); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private Button button(String label, boolean emphasized, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(emphasized ? BG : FOREGROUND);
        b.setBackgroundTintList(ColorStateList.valueOf(emphasized ? ACCENT : SURFACE));
        b.setOnClickListener(click);
        b.setMinHeight(dp(48));
        return b;
    }

    private void addWithMargins(LinearLayout parent, View child, int top, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin=dp(top); lp.bottomMargin=dp(bottom);
        parent.addView(child,lp);
    }

    private LinearLayout scaffold(String title, String caption) {
        LinearLayout root=vertical();
        root.setBackgroundColor(BG);
        // Android 15+ uses edge-to-edge, and our old fixed 13dp padding
        // overlapped the status bar / bottom navigation buttons.
        root.setPadding(dp(17),dp(22),dp(17),dp(28));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            root.setPadding(dp(17) + bars.left, dp(22) + bars.top,
                    dp(17) + bars.right, dp(28) + bars.bottom);
            return insets;
        });
        addWithMargins(root,text(title,27,FOREGROUND,true),2,0);
        if (caption!=null && !caption.isEmpty()) addWithMargins(root,text(caption,13,MUTED,false),3,11);
        setContentView(root);
        return root;
    }

    private void showPermission() {
        currentScreen="permission";
        LinearLayout root=scaffold("픽서랍", "내 사진은 내 휴대폰에서만 분석");
        TextView msg=text("정리할 앨범을 고르려면 사진 접근 권한이 필요해요.\n사진을 서버로 전송하거나 자동으로 삭제하지 않습니다.",16,FOREGROUND,false);
        msg.setLineSpacing(dp(6),1.0f);
        addWithMargins(root,msg,dp(30),dp(24));
        addWithMargins(root,button("사진 접근 허용",true,v->requestPhotoAccess()),0,0);
    }

    private void loadAlbums() {
        currentScreen="loading";
        LinearLayout root=scaffold("앨범 불러오는 중", "휴대폰 사진 목록을 확인하고 있어요");
        ProgressBar bar = new ProgressBar(this);
        addWithMargins(root,bar,12,0);
        worker.execute(()-> {
            try {
                List<PhotoInfo> photos=repository.getPhotos();
                Map<String,List<PhotoInfo>> buckets=repository.albums(photos);
                main.post(()-> {
                    if (isFinishing()) return;
                    library=photos;
                    albums=buckets;
                    selectedAlbums.retainAll(albums.keySet());
                    showAlbums();
                });
            } catch (Exception ex) {
                main.post(()-> new AlertDialog.Builder(this)
                        .setTitle("앨범을 읽을 수 없어요")
                        .setMessage(ex.getMessage())
                        .setPositiveButton("다시 시도",(d,w)->showPermission())
                        .show());
            }
        });
    }

    private void showAlbums() {
        currentScreen="albums";
        LinearLayout root=scaffold("픽서랍", "앨범을 골라서 한 번에 분석해요");
        if (partialAccess()) {
            TextView warning=text("현재 일부 사진만 접근하도록 설정되어 있어요. 전체 앨범을 보려면 권한을 변경하세요.",13,RED,false);
            addWithMargins(root,warning,3,6);
            addWithMargins(root,button("사진 접근 권한 변경",false,v->requestPhotoAccess()),0,8);
        }
        LinearLayout bar=horizontal();
        TextView title=text("앨범 " + albums.size() + "개 · 사진 " + library.size() + "장",14,FOREGROUND,true);
        bar.addView(title,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        Button all=button("전체 선택",false,v->{
            selectedAlbums.clear(); selectedAlbums.addAll(albums.keySet()); showAlbums();
        });
        bar.addView(all);
        Button none=button("해제",false,v->{selectedAlbums.clear();showAlbums();});
        bar.addView(none);
        addWithMargins(root,bar,4,8);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list=vertical();
        for (Map.Entry<String,List<PhotoInfo>> entry:albums.entrySet()) {
            String bucket=entry.getKey();
            List<PhotoInfo> photos=entry.getValue();
            LinearLayout line=horizontal();
            line.setPadding(dp(6),dp(6),dp(6),dp(6));
            ImageView cover=new ImageView(this);
            cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cover.setBackgroundColor(SURFACE);
            line.addView(cover,new LinearLayout.LayoutParams(dp(64),dp(64)));
            if (!photos.isEmpty()) thumbs.load(cover,photos.get(0).uri,160);
            CheckBox box=new CheckBox(this);
            box.setText(photos.get(0).bucketName+"\n"+photos.size()+"장");
            box.setTextSize(15);
            box.setTextColor(FOREGROUND);
            box.setButtonTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{ACCENT,MUTED}));
            box.setChecked(selectedAlbums.contains(bucket));
            line.addView(box,new LinearLayout.LayoutParams(0,dp(70),1));
            box.setOnCheckedChangeListener((b,checked)->{
                if (checked) selectedAlbums.add(bucket); else selectedAlbums.remove(bucket);
            });
            line.setOnClickListener(v->box.setChecked(!box.isChecked()));
            list.addView(line);
            View divider=new View(this); divider.setBackgroundColor(SURFACE);
            list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        if (albums.isEmpty()) addWithMargins(list,text("보이는 사진이 없어요. 접근 권한을 확인해 주세요.",15,MUTED,false),20,20);
        scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button go=button("선택한 앨범 분석하기",true,v->startAnalysis());
        addWithMargins(root,go,8,12);
        addWithMargins(root,text("이 단계에서는 사진을 옮기거나 삭제하지 않아요.",12,MUTED,false),2,0);
    }

    private void startAnalysis() {
        if (selectedAlbums.isEmpty()) {
            Toast.makeText(this,"앨범을 하나 이상 선택해 주세요.",Toast.LENGTH_SHORT).show();
            return;
        }
        scanned=new ArrayList<>();
        for (PhotoInfo p:library) if (selectedAlbums.contains(p.bucketId)) scanned.add(p);
        if (scanned.isEmpty()) { Toast.makeText(this,"사진이 없는 앨범이에요.",Toast.LENGTH_SHORT).show(); return; }
        cancel.set(false);
        movedInSession.clear();
        movePlanInitialized = false;
        selectedMoveTargets.clear();
        showProgress(scanned.size());
        worker.execute(()->{
            int done=0,failed=0;
            try (PhotoAnalyzer analyzer=new PhotoAnalyzer(this)) {
                for (PhotoInfo p:scanned) {
                    if (cancel.get()) break;
                    if (!p.analyzed && !analyzer.analyze(p)) failed++;
                    done++;
                    int current=done, errors=failed;
                    if (done==1 || done%5==0 || done==scanned.size()) {
                        main.post(()->{
                            if ("analyzing".equals(currentScreen)) updateProgress(current,scanned.size(),errors);
                        });
                    }
                    if (done%70==0) repository.saveCache(scanned);
                }
            } catch (Exception e) {
                android.util.Log.e("PhotoTidy","Analysis error",e);
            } finally {
                repository.saveCache(scanned);
                main.post(()->{
                    if (isFinishing()) return;
                    result=new Groups(scanned,personOverrides);
                    deleteSelection.clear();
                    chosenKeep.clear();
                    personEditSelection.clear();
                    personEditMode=false;
                    currentCategory="people";
                    currentPerson=-1;
                    currentSimilar=-1;
                    showResults();
                    if (cancel.get()) Toast.makeText(this,"중단 전까지 분석한 결과를 표시해요.",Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showProgress(int count) {
        currentScreen="analyzing";
        LinearLayout root=scaffold("사진 분석 중", "앱을 열어둔 상태에서 분석해요");
        progressLabel=text("0 / "+count+"장",20,FOREGROUND,true);
        addWithMargins(root,progressLabel,18,8);
        progressBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(count);
        progressBar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        addWithMargins(root,progressBar,1,16);
        addWithMargins(root,text("인물 수 · 반려동물 · 흔들림 · 비슷한 사진을 확인하고 있어요.\n이미 분석한 사진은 저장된 결과를 사용합니다.",14,MUTED,false),0,20);
        addWithMargins(root,button("여기까지 분석하고 결과 보기",false,v->cancel.set(true)),0,0);
    }

    private void updateProgress(int done,int count,int failed) {
        if (progressLabel==null || progressBar==null) return;
        progressLabel.setText(done+" / "+count+"장"+(failed>0?" · 확인 실패 "+failed+"장":""));
        progressBar.setProgress(done);
    }

    private void showResults() {
        currentScreen="results";
        LinearLayout root=scaffold("분석 결과",result.all.size()+"장 분석 · 사진 삭제는 직접 선택해요");
        addWithMargins(root,button("← 앨범 다시 선택",false,v->showAlbums()),0,4);
        addWithMargins(root,button("📁 분류 결과로 실제 앨범 만들기",true,v->showMovePlanner()),0,6);
        HorizontalScrollView filters = new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=horizontal();
        int peoplePhotos = 0;
        for (List<PhotoInfo> group : result.people.values()) peoplePhotos += group.size();
        addChip(chips,"👤 인물별", "people", peoplePhotos);
        addChip(chips,"👨‍👩‍👧 함께", "together", result.together.size());
        addChip(chips,"❔ 미분류", "unclassified", result.unclassified.size());
        addChip(chips,"🐾 동물", "pets", result.pets.size());
        addChip(chips,"≋ 비슷한", "similar", result.similar.size());
        addChip(chips,"🗑 삭제 추천", "candidates", result.candidates.size());
        filters.addView(chips);
        addWithMargins(root,filters,3,10);

        List<PhotoInfo> display = new ArrayList<>();
        if ("people".equals(currentCategory)) {
            addWithMargins(root,text("연속 촬영으로 일치한 사진만 묶었어요. 한 장만 있거나 확신할 수 없으면 미분류로 남겨요. 후보를 여러 개 한 번에 합칠 수도 있어요.",12,MUTED,false),0,3);
            addPersonPicker(root);
            if (result.people.containsKey(currentPerson)) display.addAll(result.people.get(currentPerson));
            LinearLayout actions=horizontal();
            Button edit=button(personEditMode?"✓ 분류 수정 끝내기":"✎ 인물 분류 수정",false,v->{
                personEditMode=!personEditMode;
                personEditSelection.clear();
                showResults();
            });
            actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1f));
            if (personEditMode) {
                Button all=button("이 그룹 전체 선택",false,v->{
                    personEditSelection.clear();
                    personEditSelection.addAll(ids(result.people.get(currentPerson)));
                    showResults();
                });
                actions.addView(all,new LinearLayout.LayoutParams(0,-2,1f));
            }
            addWithMargins(root,actions,0,3);
        } else if ("similar".equals(currentCategory)) {
            addWithMargins(root,text("비슷한 사진은 선명도 순서로 정리했어요. 어느 사진을 남길지는 직접 골라요.",12,MUTED,false),0,3);
            addSimilarPicker(root);
            if (result.similar.containsKey(currentSimilar)) display.addAll(result.similar.get(currentSimilar));
            if (!display.isEmpty()) addWithMargins(root,button("🔍 이 묶음 나란히 비교하기",true,v->showCompareScreen()),0,4);
        } else if ("together".equals(currentCategory)) {
            display.addAll(result.together);
            addWithMargins(root,text("2명 이상 함께 나온 사진은 한곳에 모았어요.",12,MUTED,false),0,3);
        } else if ("pets".equals(currentCategory)) {
            display.addAll(result.pets);
            addWithMargins(root,text("동물로 확실하게 판별된 사진만 모았어요. 잘못된 사진은 길게 눌러 미분류로 옮겨요.",12,MUTED,false),0,3);
        } else if ("candidates".equals(currentCategory)) {
            display.addAll(result.candidates);
            addWithMargins(root,text("삭제 후보일 뿐이에요. 어둡거나 흔들린 사진도 소중할 수 있어요.",12,RED,false),0,3);
        } else if ("unclassified".equals(currentCategory)) {
            display.addAll(result.unclassified);
            addWithMargins(root,text("판단이 어렵거나 분류가 확실하지 않은 사진이에요. 원래 앨범에 그대로 두며 실제 앨범 이동 대상에서 제외해요.",12,MUTED,false),0,3);
            addWithMargins(root,button(unclassifiedAssignMode?"✓ 인물 직접 분류 종료":"👤 미분류 사진 여러 장을 인물로 묶기",false,v->{
                unclassifiedAssignMode=!unclassifiedAssignMode;
                personEditSelection.clear();
                showResults();
            }),0,4);
        }

        final boolean editing=("people".equals(currentCategory) && personEditMode)
                || ("unclassified".equals(currentCategory) && unclassifiedAssignMode);
        String hint=editing?("unclassified".equals(currentCategory)
                ? "인물로 묶을 사진을 여러 장 골라 한 번에 지정하세요"
                : "터치해 다른 인물로 옮길 사진을 고르세요"):
                "unclassified".equals(currentCategory)
                ? "사진을 길게 누르면 미분류 지정/해제를 확인해요. 터치하면 삭제 후보로 선택돼요."
                : "터치해 휴지통으로 보낼 사진을 골라요";
        addWithMargins(root,text("사진 "+display.size()+"장 · "+hint,13,MUTED,false),7,5);
        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setVerticalSpacing(dp(4));
        grid.setHorizontalSpacing(dp(4));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setCacheColorHint(Color.TRANSPARENT);
        PhotoGridAdapter adapter=new PhotoGridAdapter(display,editing);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((a,v,index,id)->{
            PhotoInfo p=display.get(index);
            Set<Long> selection=editing?personEditSelection:deleteSelection;
            if (!selection.add(p.id)) selection.remove(p.id);
            adapter.notifyDataSetChanged();
            updateBottomSelection();
        });
        grid.setOnItemLongClickListener((a,v,index,id)->{ showPreview(display.get(index)); return true; });
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        addWithMargins(root,text("사진을 길게 누르면 크게 볼 수 있어요.",12,MUTED,false),7,3);
        bottomSelection = button("선택한 사진 0장",true,v->{
            if ("unclassified".equals(currentCategory) && unclassifiedAssignMode) assignUnclassifiedPhotos();
            else if (editing) moveSelectedPersonPhotos();
            else confirmTrash();
        });
        addWithMargins(root,bottomSelection,4,0);
        updateBottomSelection();
    }

    private static Set<Long> ids(List<PhotoInfo> photos) {
        Set<Long> values=new HashSet<>();
        if (photos!=null) for (PhotoInfo p:photos) values.add(p.id);
        return values;
    }

    private Button bottomSelection;
    private void updateBottomSelection() {
        if (bottomSelection==null) return;
        boolean classifying="unclassified".equals(currentCategory) && unclassifiedAssignMode && "results".equals(currentScreen);
        boolean editing=("people".equals(currentCategory) && personEditMode && "results".equals(currentScreen)) || classifying;
        int count=editing?personEditSelection.size():deleteSelection.size();
        if (classifying) bottomSelection.setText(count==0?"인물로 묶을 사진을 골라 주세요":count+"장 · 인물로 묶기");
        else if (editing) bottomSelection.setText(count==0?"옮길 사진을 먼저 선택해 주세요":count+"장 · 다른 인물로 옮기기");
        else bottomSelection.setText(count==0?"삭제할 사진을 직접 선택해 주세요":"선택한 "+count+"장 · 휴지통으로");
        bottomSelection.setEnabled(count>0);
    }

    private void addChip(LinearLayout parent,String name,String category,int count) {
        Button b=button(name+" "+count,currentCategory.equals(category),v->{
            currentCategory=category;
            currentPerson=-1;
            currentSimilar=-1;
            compareScrollX=0;
            personEditMode=false;
            unclassifiedAssignMode=false;
            personEditSelection.clear();
            showResults();
        });
        parent.addView(b);
    }

    private void addPersonPicker(LinearLayout root) {
        if (result.people.isEmpty()) {
            addWithMargins(root,text("인물 후보가 아직 없어요.",14,MUTED,false),8,8);
            return;
        }
        if (!result.people.containsKey(currentPerson)) currentPerson=result.people.keySet().iterator().next();
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=horizontal();
        int sequence=1;
        for (Map.Entry<Long,List<PhotoInfo>> entry:result.people.entrySet()) {
            long key=entry.getKey();
            String label=personName(key,sequence++);
            Button b=button(label+" · "+entry.getValue().size(),currentPerson==key,v->{
                currentPerson=key;
                personEditSelection.clear();
                showResults();
            });
            row.addView(b);
        }
        scroll.addView(row);
        addWithMargins(root,scroll,0,4);
        addWithMargins(root,button("현재 인물 이름 붙이기 ✎",false,v->renameCurrentPerson()),0,1);
        if (result.people.size() > 1) {
            addWithMargins(root,button("✓ 여러 인물 후보 한 번에 합치기",true,v->mergeMultiplePersonGroups()),0,3);
        }
    }

    private void addSimilarPicker(LinearLayout root) {
        if (result.similar.isEmpty()) {
            addWithMargins(root,text("비슷한 사진 묶음이 아직 없어요.",14,MUTED,false),8,8);
            return;
        }
        if (!result.similar.containsKey(currentSimilar)) currentSimilar=result.similar.keySet().iterator().next();
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=horizontal();
        for (Map.Entry<Integer,List<PhotoInfo>> entry:result.similar.entrySet()) {
            int key=entry.getKey();
            Button b=button("묶음 "+(key+1)+" · "+entry.getValue().size(),currentSimilar==key,v->{
                currentSimilar=key;
                compareScrollX=0;
                showResults();
            });
            row.addView(b);
        }
        scroll.addView(row);
        addWithMargins(root,scroll,0,4);
    }

    private String personName(long group,int fallbackIndex) {
        String name=personOverrides.name(group);
        return name==null || name.isEmpty()?"인물 후보 "+fallbackIndex:name;
    }

    /** The current group is the destination; checked groups are moved all at
     * once, without requiring the owner to visit each group individually. */
    private void mergeMultiplePersonGroups() {
        List<Long> candidates = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 1;
        for (Map.Entry<Long,List<PhotoInfo>> entry:result.people.entrySet()) {
            if (entry.getKey() != currentPerson) {
                candidates.add(entry.getKey());
                labels.add(personName(entry.getKey(), index) + " · " + entry.getValue().size() + "장");
            }
            index++;
        }
        if (candidates.isEmpty()) return;
        boolean[] chosen = new boolean[candidates.size()];
        new AlertDialog.Builder(this)
                .setTitle("같은 사람 후보 여러 개 선택")
                .setMessage("현재 선택한 인물에 합칠 그룹을 모두 체크하세요. 정확히 같은 사람일 때만 합쳐 주세요. 사진 파일은 이동하지 않아요.")
                .setMultiChoiceItems(labels.toArray(new String[0]), chosen,
                        (dialog, which, checked) -> chosen[which] = checked)
                .setNegativeButton("취소", null)
                .setPositiveButton("선택한 그룹 합치기", (dialog, which) -> {
                    List<PhotoInfo> destination=result.people.get(currentPerson);
                    if (destination == null || destination.isEmpty()) return;
                    List<PhotoInfo> moving = new ArrayList<>();
                    for (int i=0;i<candidates.size();i++) {
                        if (chosen[i]) {
                            List<PhotoInfo> group=result.people.get(candidates.get(i));
                            if (group != null) moving.addAll(group);
                        }
                    }
                    if (moving.isEmpty()) {
                        Toast.makeText(this,"합칠 그룹을 선택해 주세요.",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    personOverrides.pinGroup(currentPerson,destination);
                    personOverrides.move(moving,currentPerson);
                    result=new Groups(scanned,personOverrides);
                    showResults();
                    Toast.makeText(this,moving.size()+"장을 현재 인물에 합쳤어요.",Toast.LENGTH_LONG).show();
                })
                .show();
    }

    /** Owner can select many uncertain photos from the grid and assign them
     * to a known identity in one operation. This changes app metadata only. */
    private void assignUnclassifiedPhotos() {
        if (personEditSelection.isEmpty()) return;
        List<PhotoInfo> selected = new ArrayList<>();
        for (PhotoInfo p:result.unclassified) if (personEditSelection.contains(p.id)) selected.add(p);
        if (selected.isEmpty()) return;
        List<Long> destinations = new ArrayList<>();
        List<String> options = new ArrayList<>();
        options.add("＋ 새 사람으로 지정하고 이름 붙이기");
        int index = 1;
        for (Map.Entry<Long,List<PhotoInfo>> entry:result.people.entrySet()) {
            destinations.add(entry.getKey());
            options.add(personName(entry.getKey(),index++)+" · "+entry.getValue().size()+"장");
        }
        new AlertDialog.Builder(this).setTitle(selected.size()+"장을 어느 사람으로 묶을까요?")
                .setItems(options.toArray(new String[0]),(d,which)->{
                    if (which==0) {
                        EditText input=new EditText(this);
                        input.setSingleLine(true);
                        input.setHint("예: 유나");
                        new AlertDialog.Builder(this)
                                .setTitle("새 인물 이름")
                                .setView(input)
                                .setNegativeButton("취소",null)
                                .setPositiveButton("저장",(dd,ww)->{
                                    String name=input.getText().toString().trim();
                                    if (name.isEmpty()) {
                                        Toast.makeText(this,"이름을 입력해 주세요.",Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    long group=personOverrides.createGroup();
                                    personOverrides.move(selected,group);
                                    personOverrides.rename(group,name);
                                    unclassifiedAssignMode=false;
                                    personEditSelection.clear();
                                    result=new Groups(scanned,personOverrides);
                                    currentCategory="people";
                                    currentPerson=group;
                                    showResults();
                                }).show();
                    } else {
                        long group=destinations.get(which-1);
                        List<PhotoInfo> existing=result.people.get(group);
                        if (existing!=null) personOverrides.pinGroup(group,existing);
                        personOverrides.move(selected,group);
                        unclassifiedAssignMode=false;
                        personEditSelection.clear();
                        result=new Groups(scanned,personOverrides);
                        currentCategory="people";
                        currentPerson=group;
                        showResults();
                    }
                }).setNegativeButton("취소",null).show();
    }

    private void renameCurrentPerson() {
        List<PhotoInfo> group=result.people.get(currentPerson);
        if (group==null || group.isEmpty()) return;
        EditText input=new EditText(this);
        input.setSingleLine(true);
        String name=personOverrides.name(currentPerson);
        input.setText(name==null?"":name);
        input.setHint("예: 유나");
        new AlertDialog.Builder(this).setTitle("이 인물의 이름")
                .setMessage("이름을 붙인 사진들은 다음 분석에서도 같은 그룹으로 고정돼요.")
                .setView(input)
                .setNegativeButton("취소",null)
                .setPositiveButton("저장",(d,w)->{
                    String newName=input.getText().toString().trim();
                    if (newName.isEmpty()) return;
                    personOverrides.pinGroup(currentPerson,group);
                    personOverrides.rename(currentPerson,newName);
                    result=new Groups(scanned,personOverrides);
                    showResults();
                }).show();
    }

    private void moveSelectedPersonPhotos() {
        if (personEditSelection.isEmpty()) return;
        List<PhotoInfo> moved=new ArrayList<>();
        List<PhotoInfo> current=result.people.get(currentPerson);
        if (current==null) return;
        for (PhotoInfo p:current) if (personEditSelection.contains(p.id)) moved.add(p);
        if (moved.isEmpty()) return;
        List<Long> targetIds=new ArrayList<>();
        List<String> options=new ArrayList<>();
        options.add("＋ 새 인물 그룹으로 분리");
        int i=1;
        for (Map.Entry<Long,List<PhotoInfo>> entry:result.people.entrySet()) {
            if (entry.getKey()!=currentPerson) {
                targetIds.add(entry.getKey());
                options.add(personName(entry.getKey(),i)+" ("+entry.getValue().size()+"장)");
            }
            i++;
        }
        new AlertDialog.Builder(this)
                .setTitle("선택한 "+moved.size()+"장 옮기기")
                .setItems(options.toArray(new String[0]),(d,which)->{
                    long target;
                    if (which==0) target=personOverrides.createGroup();
                    else {
                        target=targetIds.get(which-1);
                        // Pin the destination so subsequent scans don't change its members.
                        personOverrides.pinGroup(target,result.people.get(target));
                    }
                    personOverrides.move(moved,target);
                    result=new Groups(scanned,personOverrides);
                    currentPerson=target;
                    personEditSelection.clear();
                    personEditMode=false;
                    showResults();
                    Toast.makeText(this,"인물 분류를 수정했어요. 이름도 붙일 수 있어요.",Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("취소",null).show();
    }

    /** A side-by-side, horizontally scrollable comparison. No implicit keep/delete. */
    private void showCompareScreen() {
        List<PhotoInfo> photos=result.similar.get(currentSimilar);
        if (photos==null || photos.isEmpty()) {showResults();return;}
        currentScreen="compare";
        LinearLayout root=scaffold("비슷한 사진 비교", "묶음 "+(currentSimilar+1)+" · "+photos.size()+"장 · 마지막 삭제 결정은 직접");
        addWithMargins(root,button("← 분석 결과로",false,v->showResults()),0,4);
        addWithMargins(root,text("좌우로 넘기면서 사진을 비교해요. '남기기'만 눌러도 다른 사진은 삭제되지 않아요.",13,MUTED,false),2,10);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout strip=horizontal();
        strip.setGravity(Gravity.TOP);
        Long keep=chosenKeep.get(currentSimilar);
        int rank=1;
        for (PhotoInfo photo:photos) {
            LinearLayout card=vertical();
            card.setBackgroundColor(SURFACE);
            card.setPadding(dp(6),dp(8),dp(6),dp(9));
            LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(dp(178),-2);
            cardLp.rightMargin=dp(7);
            ImageView preview=new ImageView(this);
            preview.setBackgroundColor(BG);
            preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
            card.addView(preview,new LinearLayout.LayoutParams(-1,dp(245)));
            thumbs.load(preview,photo.uri,680);
            preview.setOnClickListener(v->showPreview(photo));
            String state=keep!=null && keep==photo.id?"❤️ 남기기로 선택":deleteSelection.contains(photo.id)?"🗑 삭제 목록에 담김": " ";
            addWithMargins(card,text(state,12,keep!=null && keep==photo.id?ACCENT:MUTED,true),5,3);
            String when=photo.taken>0?new SimpleDateFormat("yy.MM.dd HH:mm",Locale.KOREA).format(new Date(photo.taken)):"촬영 날짜 미확인";
            addWithMargins(card,text("#"+rank++ + " · " + when,12,MUTED,false),0,5);
            Button keepButton=button(keep!=null && keep==photo.id?"✓ 남길 사진":"❤️ 이 사진 남기기",keep!=null && keep==photo.id,v->{
                chosenKeep.put(currentSimilar,photo.id);
                deleteSelection.remove(photo.id);
                showCompareScreen();
            });
            addWithMargins(card,keepButton,0,3);
            Button deleteButton=button(deleteSelection.contains(photo.id)?"삭제 선택 취소":"🗑 삭제 목록에 추가",false,v->{
                if (!deleteSelection.add(photo.id)) deleteSelection.remove(photo.id);
                if (photo.id==chosenKeep.getOrDefault(currentSimilar,Long.MIN_VALUE)) chosenKeep.remove(currentSimilar);
                showCompareScreen();
            });
            addWithMargins(card,deleteButton,0,0);
            strip.addView(card,cardLp);
        }
        scroll.addView(strip);
        scroll.setOnScrollChangeListener((v,x,y,oldX,oldY)->compareScrollX=x);
        scroll.post(()->scroll.scrollTo(compareScrollX,0));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        Button selectOthers=button("남길 1장 외 나머지를 삭제 목록에 담기",true,v->addOtherSimilarToTrash(photos));
        selectOthers.setEnabled(keep!=null);
        addWithMargins(root,selectOthers,7,2);
        addWithMargins(root,text("이 버튼은 삭제 목록만 만드는 기능이에요. 실제 휴지통 이동은 다시 확인해야 해요.",12,MUTED,false),1,5);
        bottomSelection=button("휴지통으로 이동",false,v->confirmTrash());
        addWithMargins(root,bottomSelection,2,0);
        updateBottomSelection();
    }

    private void addOtherSimilarToTrash(List<PhotoInfo> photos) {
        Long keep=chosenKeep.get(currentSimilar);
        if (keep==null) return;
        new AlertDialog.Builder(this)
                .setTitle("나머지를 삭제 목록에 담을까요?")
                .setMessage("선택한 1장은 남기고 다른 "+(photos.size()-1)+"장을 삭제 목록에 넣어요. 실제 삭제는 아직 하지 않아요.")
                .setNegativeButton("취소",null)
                .setPositiveButton("삭제 목록에 담기",(d,w)->{
                    deleteSelection.remove(keep);
                    for (PhotoInfo p:photos) if(p.id!=keep) deleteSelection.add(p.id);
                    showCompareScreen();
                }).show();
    }

    private final class PhotoGridAdapter extends BaseAdapter {
        private final List<PhotoInfo> photos;
        private final boolean editing;
        PhotoGridAdapter(List<PhotoInfo> photos,boolean editing) {this.photos=photos;this.editing=editing;}
        @Override public int getCount(){return photos.size();}
        @Override public Object getItem(int position){return photos.get(position);}
        @Override public long getItemId(int position){return photos.get(position).id;}
        @Override public View getView(int position,View reusable,ViewGroup parent) {
            FrameLayout frame;
            ImageView image;
            TextView check;
            if (reusable instanceof FrameLayout && reusable.getTag() instanceof FrameHolder) {
                frame=(FrameLayout)reusable;
                FrameHolder holder=(FrameHolder)frame.getTag();
                image=holder.image;
                check=holder.check;
            } else {
                frame=new FrameLayout(MainActivity.this);
                image=new ImageView(MainActivity.this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(SURFACE);
                frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
                check=text("✓",20,Color.WHITE,true);
                check.setGravity(Gravity.CENTER);
                FrameLayout.LayoutParams marker=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.TOP|Gravity.END);
                frame.addView(check,marker);
                frame.setTag(new FrameHolder(image,check));
            }
            int width=(getResources().getDisplayMetrics().widthPixels-dp(44))/3;
            frame.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1,width));
            PhotoInfo photo=photos.get(position);
            thumbs.load(image,photo.uri,320);
            boolean selected=(editing?personEditSelection:deleteSelection).contains(photo.id);
            check.setBackgroundColor(selected?Color.rgb(81,123,188):Color.argb(145,14,17,24));
            check.setText(selected?"✓":"○");
            check.setTextColor(selected?Color.WHITE:MUTED);
            frame.setForeground(null);
            return frame;
        }
    }

    private static final class FrameHolder {
        final ImageView image;
        final TextView check;
        FrameHolder(ImageView image,TextView check) {this.image=image;this.check=check;}
    }

    private void showPreview(PhotoInfo p) {
        LinearLayout view=vertical();
        view.setPadding(dp(8),dp(8),dp(8),dp(8));
        ImageView image=new ImageView(this);
        image.setBackgroundColor(SURFACE);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.addView(image,new LinearLayout.LayoutParams(-1,dp(390)));
        thumbs.load(image,p.uri,1200);
        String message = result != null && result.unclassifiedIds.contains(p.id)
                ? "미분류 사진입니다. 원래 앨범에 그대로 있으며 이동하지 않아요."
                : p.deleteCandidate ? p.reason : "직접 확인한 뒤 삭제 여부를 선택하세요.";
        addWithMargins(view,text(message,13,MUTED,false),8,2);
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setView(view)
                .setNegativeButton("닫기",null);
        boolean forcedUnknown = personOverrides.isUnclassified(p.id);
        // Let the owner override a wrong person/animal/group classification.
        // This never moves or deletes an original file.
        dialog.setNeutralButton(forcedUnknown ? "미분류 지정 취소" : "미분류로 지정", (d,w)->{
            personOverrides.setUnclassified(p.id, !forcedUnknown);
            if (!forcedUnknown) {
                deleteSelection.remove(p.id);
                personEditSelection.remove(p.id);
            }
            result = new Groups(scanned, personOverrides);
            if ("review".equals(currentScreen)) showDeleteReview();
            else if ("compare".equals(currentScreen)) showCompareScreen();
            else showResults();
            Toast.makeText(this, forcedUnknown ? "자동 분류로 다시 돌아갔어요." : "미분류로 지정했어요. 실제 앨범으로 이동하지 않아요.", Toast.LENGTH_LONG).show();
        });
        // Preview in person-correction mode must never mark a photo for deletion.
        if (!("results".equals(currentScreen) &&
                (("people".equals(currentCategory) && personEditMode)
                || ("unclassified".equals(currentCategory) && unclassifiedAssignMode)))) {
            dialog.setPositiveButton(deleteSelection.contains(p.id)?"삭제 선택 취소":"삭제 후보로 선택",(d,w)->{
                if (!deleteSelection.add(p.id)) deleteSelection.remove(p.id);
                if (p.id==chosenKeep.getOrDefault(currentSimilar,Long.MIN_VALUE)) chosenKeep.remove(currentSimilar);
                if ("review".equals(currentScreen)) showDeleteReview();
                else if ("compare".equals(currentScreen)) showCompareScreen();
                else showResults();
            });
        }
        dialog.show();
    }

    /** An explicit, full-size last review with selectable thumbnails.
     *  Touching a selected thumbnail here REMOVES it from the trash list. */
    private void confirmTrash() {
        if (deleteSelection.isEmpty()) return;
        returnFromReview = "compare".equals(currentScreen) ? "compare" : "results";
        showDeleteReview();
    }

    private void leaveDeleteReview() {
        if ("compare".equals(returnFromReview)) showCompareScreen();
        else showResults();
    }

    private List<PhotoInfo> selectedForDeletion() {
        List<PhotoInfo> selected = new ArrayList<>();
        // Only the explicitly scanned/selected albums are ever eligible.
        for (PhotoInfo p : scanned) if (deleteSelection.contains(p.id)) selected.add(p);
        return selected;
    }

    private void showDeleteReview() {
        List<PhotoInfo> selected = selectedForDeletion();
        if (selected.isEmpty()) {
            deleteSelection.clear();
            leaveDeleteReview();
            return;
        }
        currentScreen = "review";
        LinearLayout root = scaffold("삭제 전 최종 확인", selected.size() + "장 선택됨 · 실제 삭제는 아직 하지 않았어요");
        addWithMargins(root, button("← 이전 화면으로", false, v -> leaveDeleteReview()), 0, 7);
        TextView warning = text("선택된 사진을 모두 다시 확인해 주세요.\n사진을 한 번 누르면 삭제 목록에서 제외돼요. 길게 누르면 크게 볼 수 있어요.", 14, RED, false);
        warning.setLineSpacing(dp(3), 1.0f);
        addWithMargins(root, warning, 2, 10);

        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setVerticalSpacing(dp(4));
        grid.setHorizontalSpacing(dp(4));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setAdapter(new PhotoGridAdapter(selected, false));
        grid.setOnItemClickListener((parent, view, index, id) -> {
            PhotoInfo p = selected.get(index);
            deleteSelection.remove(p.id);
            showDeleteReview();
        });
        grid.setOnItemLongClickListener((parent, view, index, id) -> {
            showPreview(selected.get(index));
            return true;
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        int batch = Math.min(MAX_TRASH_BATCH, selected.size());
        addWithMargins(root, text(selected.size() > MAX_TRASH_BATCH
                ? "안전을 위해 이번에는 " + batch + "장만 요청해요. 나머지는 다음 확인에서 진행해요."
                : "휴지통으로 보낸 사진은 기기/갤러리 정책에 따라 복원이 제한될 수 있어요.",
                12, MUTED, false), 8, 5);
        addWithMargins(root, button("선택한 " + batch + "장 · 휴지통 이동 확인", true,
                v -> confirmSystemTrash()), 2, 0);
    }

    private void confirmSystemTrash() {
        List<PhotoInfo> selected = selectedForDeletion();
        if (selected.isEmpty()) { showDeleteReview(); return; }
        int batch = Math.min(MAX_TRASH_BATCH, selected.size());
        String message = selected.size() > MAX_TRASH_BATCH
                ? "총 " + selected.size() + "장 중 " + batch + "장만 이번에 요청합니다. 남은 사진은 다음에 다시 확인해야 해요. 안드로이드 시스템에서도 승인해야 실제 휴지통으로 이동합니다."
                : "이 " + batch + "장을 휴지통으로 보낼까요? 안드로이드 시스템에서도 직접 승인해야 합니다.";
        new AlertDialog.Builder(this)
                .setTitle("마지막 확인 · " + batch + "장")
                .setMessage(message)
                .setNegativeButton("취소", null)
                .setPositiveButton("시스템 확인창 열기", (d, w) -> trashSelected())
                .show();
    }

    private void trashSelected() {
        List<Uri> uris = new ArrayList<>();
        pendingTrashIds.clear();
        for (PhotoInfo p : selectedForDeletion()) {
            if (uris.size() == MAX_TRASH_BATCH) break;
            uris.add(p.uri);
            pendingTrashIds.add(p.id);
        }
        if (uris.isEmpty()) return;
        try {
            PendingIntent intent = MediaStore.createTrashRequest(getContentResolver(), uris, true);
            startIntentSenderForResult(intent.getIntentSender(), REQ_TRASH, null, 0, 0, 0);
        } catch (Exception e) {
            pendingTrashIds.clear();
            new AlertDialog.Builder(this).setTitle("휴지통 이동 실패")
                    .setMessage("이 사진에 대한 접근 권한을 확인해 주세요.\n" + e.getMessage())
                    .setPositiveButton("확인", null).show();
        }
    }


    /** A gallery folder can hold each photo at only one physical location.
     *  Heuristic similar/deletion categories remain virtual, never auto moved.
     *  Only user-named people groups can be exported: suggested face identities
     *  are not reliable enough for irreversible folder rearrangements. */
    private Map<String,List<PhotoInfo>> moveAlbumPlan() {
        Map<String,List<PhotoInfo>> plan = new LinkedHashMap<>();
        if (result == null) return plan;
        for (PhotoInfo p : result.all) {
            if (movedInSession.contains(p.id)) continue;
            // Safety invariant: uncertain, unreadable, manually excluded photos
            // must never be moved into a physical gallery album.
            if (!p.analyzed || result.unclassifiedIds.contains(p.id)) continue;
            if (p.relativePath != null && p.relativePath.startsWith(PHOTO_FOLDER)) continue;
            if (p.deleteCandidate) continue; // retain uncertain photographs in the source album
            String folder = null;
            if (p.faces >= 2) {
                folder = PHOTO_FOLDER + "함께 나온 사진/";
            } else if (p.faces == 1 && p.personGroup != -1) {
                String name = personOverrides.name(p.personGroup);
                if (name != null && !name.trim().isEmpty())
                    folder = PHOTO_FOLDER + "인물/" + safeFolderName(name) + "/";
            }
            if (folder == null && p.faces == 0 && p.pet && p.petConfidence >= 0.94) folder = PHOTO_FOLDER + "반려동물/";
            if (folder != null && !result.unclassifiedIds.contains(p.id))
                plan.computeIfAbsent(folder,k -> new ArrayList<>()).add(p);
        }
        return plan;
    }

    /** Disallow path traversal and reserved punctuation in user-provided names. */
        private String safeFolderName(String raw) {
            String result = raw.replace('\\','_').replace('/','_').replace(':','_')
                    .replace('*','_').replace('?','_').replace('"','_')
                    .replace('<','_').replace('>','_').replace('|','_').trim();
            result = result.replaceAll("[\\p{Cntrl}]", "_");
            while (result.startsWith(".")) result = result.substring(1);
            if (result.length() > 38) result = result.substring(0,38).trim();
            return result.isEmpty() ? "이름 없는 인물" : result;
        }

    private String galleryAlbumLabel(String path) {
        String label = path.startsWith(PHOTO_FOLDER) ? path.substring(PHOTO_FOLDER.length()) : path;
        if (label.endsWith("/")) label = label.substring(0,label.length()-1);
        return "픽서랍 › " + label.replace("/"," › ");
    }

    private void showMovePlanner() {
        currentScreen = "movePlan";
        Map<String,List<PhotoInfo>> plan = moveAlbumPlan();
        if (!movePlanInitialized) {
            // Misclassification must never preselect physical moves.
            selectedMoveTargets.clear();
            movePlanInitialized = true;
        }
        selectedMoveTargets.retainAll(plan.keySet());
        LinearLayout root = scaffold("분류 앨범 만들기", "선택한 사진을 갤러리의 실제 앨범으로 이동해요");
        addWithMargins(root,button("← 분석 결과로",false,v->showResults()),0,5);
        TextView intro = text("'픽서랍' 폴더 안에 새 앨범을 만들어요.\n사진은 복사하거나 삭제하지 않고 위치만 옮깁니다.\n이동 전에는 원래 앨범에 그대로 있어요.",14,FOREGROUND,false);
        intro.setLineSpacing(dp(3),1f);
        addWithMargins(root,intro,3,8);
        LinearLayout actions = horizontal();
        actions.addView(button("전체 선택",false,v->{ selectedMoveTargets.addAll(plan.keySet()); showMovePlanner(); }),new LinearLayout.LayoutParams(0,-2,1));
        actions.addView(button("선택 해제",false,v->{ selectedMoveTargets.clear(); showMovePlanner(); }),new LinearLayout.LayoutParams(0,-2,1));
        addWithMargins(root,actions,0,4);
        ScrollView scroll = new ScrollView(this);
        LinearLayout items = vertical();
        for (Map.Entry<String,List<PhotoInfo>> entry : plan.entrySet()) {
            String path = entry.getKey();
            List<PhotoInfo> photos = entry.getValue();
            LinearLayout row = horizontal();
            row.setPadding(dp(3),dp(9),dp(3),dp(9));
            ImageView cover = new ImageView(this);
            cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cover.setBackgroundColor(SURFACE);
            row.addView(cover,new LinearLayout.LayoutParams(dp(54),dp(54)));
            if (!photos.isEmpty()) thumbs.load(cover,photos.get(0).uri,150);
            CheckBox check = new CheckBox(this);
            check.setText(galleryAlbumLabel(path) + "\n" + photos.size() + "장");
            check.setTextColor(FOREGROUND);
            check.setTextSize(14);
            check.setChecked(selectedMoveTargets.contains(path));
            check.setOnCheckedChangeListener((v,isChecked)->{
                if (isChecked) selectedMoveTargets.add(path); else selectedMoveTargets.remove(path);
                updateMoveButton(plan);
            });
            row.addView(check,new LinearLayout.LayoutParams(0,-2,1));
            row.setOnClickListener(v->check.setChecked(!check.isChecked()));
            items.addView(row);
            View line=new View(this);line.setBackgroundColor(SURFACE);
            items.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        if (plan.isEmpty()) addWithMargins(items,text("이동 가능한 앨범이 아직 없어요.\n인물은 먼저 이름을 붙여야 하고, 흔들린 사진 등 삭제 후보는 안전을 위해 제외해요.",14,MUTED,false),15,15);
        scroll.addView(items);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        addWithMargins(root,text("AI가 잘못 구분할 수 있어요. 앨범별 사진을 확인하고 이동해 주세요.\n미분류·비슷한 사진·삭제 추천은 앱 안에서만 분류되며 자동 이동하지 않아요.",12,MUTED,false),10,6);
        moveButton = button("선택한 사진 이동",true,v->confirmMoveRequest(plan));
        addWithMargins(root,moveButton,2,10);
        updateMoveButton(plan);
    }

    private Button moveButton;
    private void updateMoveButton(Map<String,List<PhotoInfo>> plan) {
        if (moveButton == null) return;
        int n = 0;
        for (Map.Entry<String,List<PhotoInfo>> entry : plan.entrySet())
            if (selectedMoveTargets.contains(entry.getKey())) n+=entry.getValue().size();
        moveButton.setEnabled(n>0);
        moveButton.setText(n==0?"이동할 앨범을 선택해 주세요":
                "선택한 " + n + "장 · 앨범 이동 (한 번에 최대 " + MAX_MOVE_BATCH + "장)");
    }

    private void confirmMoveRequest(Map<String,List<PhotoInfo>> plan) {
        List<AlbumMove> batch = new ArrayList<>();
        int total = 0;
        for (Map.Entry<String,List<PhotoInfo>> entry : plan.entrySet()) {
            if (!selectedMoveTargets.contains(entry.getKey())) continue;
            total += entry.getValue().size();
            for (PhotoInfo p:entry.getValue())
                if (batch.size() < MAX_MOVE_BATCH) batch.add(new AlbumMove(p,entry.getKey()));
        }
        if (batch.isEmpty()) return;
        int next = Math.min(total,MAX_MOVE_BATCH);
        new AlertDialog.Builder(this)
                .setTitle("실제 앨범으로 사진 이동")
                .setMessage("이번에는 " + next + "장을 '픽서랍' 앨범으로 옮겨요.\n"
                        + "기존 앨범에서는 사진이 사라지고 새 앨범에서 보여요. "
                        + "복사본을 만드는 것이 아니에요.\n\n"
                        + "먼저 안드로이드의 사진 수정 허용 창에서 승인해야 진행됩니다. "
                        + (total>MAX_MOVE_BATCH?"남은 "+(total-next)+"장은 이후 추가 승인해야 해요.":""))
                .setNegativeButton("취소",null)
                .setPositiveButton("이동 권한 확인",(d,w)->requestMovePermission(batch)).show();
    }

    private void requestMovePermission(List<AlbumMove> batch) {
        pendingMoveBatch.clear();
        pendingMoveBatch.addAll(batch);
        List<Uri> uris = new ArrayList<>();
        for (AlbumMove item:batch) uris.add(item.photo.uri);
        try {
            PendingIntent intent = MediaStore.createWriteRequest(getContentResolver(),uris);
            startIntentSenderForResult(intent.getIntentSender(),REQ_MOVE,null,0,0,0);
        } catch (Exception error) {
            pendingMoveBatch.clear();
            new AlertDialog.Builder(this).setTitle("이동 권한 요청 실패")
                    .setMessage(error.getMessage()).setPositiveButton("확인",null).show();
        }
    }

    private void applyApprovedAlbumMoves() {
        final List<AlbumMove> approved = new ArrayList<>(pendingMoveBatch);
        pendingMoveBatch.clear();
        currentScreen="moving";
        LinearLayout root=scaffold("사진 이동 중", "승인한 사진만 새 앨범으로 옮기고 있어요");
        TextView counter = text("0 / " + approved.size()+"장",20,FOREGROUND,true);
        addWithMargins(root,counter,20,8);
        ProgressBar bar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(approved.size());
        addWithMargins(root,bar,0,10);
        addWithMargins(root,text("앱을 종료하지 마세요. 실패한 사진은 원래 위치에 남아요.",14,MUTED,false),0,5);
        worker.execute(()->{
            int good=0,bad=0,processed=0;
            for (AlbumMove item : approved) {
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,item.path);
                    int count = getContentResolver().update(item.photo.uri,values,null,null);
                    if (count > 0) {
                        movedInSession.add(item.photo.id);
                        good++;
                    } else bad++;
                } catch (Exception e) {
                    android.util.Log.w("PicDrawer","Could not move photo " + item.photo.id,e);
                    bad++;
                }
                processed++;
                int done=processed;
                if (done%5==0 || done==approved.size())
                    main.post(()->{if ("moving".equals(currentScreen)) {
                        counter.setText(done+" / "+approved.size()+"장");bar.setProgress(done);
                    }});
            }
            int successes=good,errors=bad;
            main.post(()->{
                if (isFinishing()) return;
                showMovePlanner();
                new AlertDialog.Builder(this)
                        .setTitle("앨범 이동 결과")
                        .setMessage("이동 완료: " + successes + "장\n이동 실패: " + errors
                                + "장\n\n성공한 사진은 갤러리의 '픽서랍' 폴더에서 볼 수 있어요. "
                                + "실패한 사진은 원래 앨범에 남아 있어요. "
                                + "남은 사진은 이 화면에서 다시 이동할 수 있어요.")
                        .setPositiveButton("확인",null).show();
            });
        });
    }


    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MOVE) {
            if (resultCode == RESULT_OK) applyApprovedAlbumMoves();
            else {
                pendingMoveBatch.clear();
                Toast.makeText(this,"앨범 이동을 취소했어요. 사진은 그대로 있어요.",Toast.LENGTH_LONG).show();
                showMovePlanner();
            }
            return;
        }
        if (requestCode != REQ_TRASH) return;
        if (resultCode == RESULT_OK) {
            int moved = pendingTrashIds.size();
            deleteSelection.removeAll(pendingTrashIds);
            pendingTrashIds.clear();
            if (deleteSelection.isEmpty()) {
                Toast.makeText(this, moved + "장 휴지통 이동 요청이 승인됐어요.", Toast.LENGTH_LONG).show();
                loadAlbums();
            } else {
                Toast.makeText(this, moved + "장 승인됨 · 남은 " + deleteSelection.size() + "장은 다시 확인해 주세요.", Toast.LENGTH_LONG).show();
                showDeleteReview();
            }
        } else {
            pendingTrashIds.clear();
            Toast.makeText(this, "휴지통 요청을 취소했어요. 선택 목록은 유지됩니다.", Toast.LENGTH_SHORT).show();
            showDeleteReview();
        }
    }

    @Override public void onBackPressed() {
        if ("analyzing".equals(currentScreen)) {
            new AlertDialog.Builder(this).setTitle("분석 중단")
                    .setMessage("현재까지 분석한 결과를 확인할까요?")
                    .setNegativeButton("계속 분석",null)
                    .setPositiveButton("중단",(d,w)->cancel.set(true)).show();
        } else if ("movePlan".equals(currentScreen)) showResults();
        else if ("moving".equals(currentScreen)) Toast.makeText(this,"현재 승인된 사진을 이동 중이에요.",Toast.LENGTH_SHORT).show();
        else if ("review".equals(currentScreen)) leaveDeleteReview();
        else if ("compare".equals(currentScreen)) showResults();
        else if ("results".equals(currentScreen)) showAlbums();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        cancel.set(true);
        worker.shutdownNow();
        thumbs.shutdown();
        super.onDestroy();
    }
}
