package com.dalkong.phototidy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Groups {
    final Map<Long,List<PhotoInfo>> people = new LinkedHashMap<>();
    final Map<Integer,List<PhotoInfo>> similar = new LinkedHashMap<>();
    final List<PhotoInfo> together = new ArrayList<>();
    final List<PhotoInfo> pets = new ArrayList<>();
    final List<PhotoInfo> candidates = new ArrayList<>();
    final List<PhotoInfo> unclassified = new ArrayList<>();
    final java.util.Set<Long> unclassifiedIds = new java.util.HashSet<>();
    final List<PhotoInfo> all = new ArrayList<>();

    Groups(List<PhotoInfo> selected, PersonOverrides overrides) {
        for (PhotoInfo p : selected) {
            // Pausing a 50,000-photo scan must not dump unprocessed photos into
            // "미분류". Only completed OR attempted-but-failed photos appear.
            if (!p.analyzed && !p.analysisFailed) continue;
            all.add(p);
            p.personGroup = -1;
            p.similarGroup = -1;
            if (p.analyzed && p.deleteCandidate) candidates.add(p);

            // Each photo belongs to EXACTLY ONE primary classification.
            if (!p.analyzed || overrides.isUnclassified(p.id)) {
                addUnclassified(p);
            } else if (p.faces >= 2) {
                together.add(p);
            } else if (overrides.get(p.id) != null) {
                // The owner may explicitly assign a previously unclassified
                // photo even if automatic face detection did not find a face.
            } else if (p.faces == 1 && p.faceFeature != null) {
                // Tentative person groups assigned in groupPeople().
            } else if (p.faces == 0 && p.pet && p.petConfidence >= 0.94) {
                pets.add(p);
            } else {
                // Screenshots, scenery, unreadable faces and weak animal labels.
                addUnclassified(p);
            }
        }
        groupPeople(overrides);
        groupSimilar();
    }

    private void addUnclassified(PhotoInfo p) {
        unclassified.add(p);
        unclassifiedIds.add(p.id);
    }

    private static double dot(float[] a, float[] b) {
        if (a == null || b == null || a.length != b.length) return -1;
        double sum=0;
        for (int i=0;i<a.length;i++) sum += a[i]*b[i];
        return sum;
    }

    /**
     * A cropped-face texture descriptor is NOT an identity-recognition embedding.
     * Only combine photos when BOTH the face crop and the near-duplicate entire image
     * agree within a short shooting session. Singles / uncertain identities must
     * stay unclassified instead of creating hundreds of misleading one-photo people.
     * Explicit owner corrections override this entire heuristic.
     */
    private void groupPeople(PersonOverrides overrides) {
        List<PhotoInfo> suggestions = new ArrayList<>();
        for (PhotoInfo p : all) {
            if (!p.analyzed || unclassifiedIds.contains(p.id)) continue;
            Long fixed = p.faces < 2 ? overrides.get(p.id) : null;
            if (fixed != null) {
                p.personGroup = fixed;
                people.computeIfAbsent(fixed, k -> new ArrayList<>()).add(p);
            } else if (p.faces == 1 && p.faceFeature != null) {
                suggestions.add(p);
            }
        }
        suggestions.sort(Comparator.comparingLong(p -> p.taken));
        int size = suggestions.size();
        int[] parent = new int[size];
        for (int i=0; i<size; i++) parent[i] = i;
        for (int i=0; i<size; i++) {
            PhotoInfo a = suggestions.get(i);
            // Limit candidate comparisons to a single photo burst (10 minutes,
            // max 90 earlier face photos); avoids quadratic scans on 50k pictures.
            for (int j=i-1; j>=0 && j>=i-90; j--) {
                PhotoInfo b = suggestions.get(j);
                if (a.taken - b.taken > 600_000L) break;
                if (!a.bucketId.equals(b.bucketId)) continue;
                if (Math.abs((double)a.width / Math.max(1,a.height)
                        - (double)b.width / Math.max(1,b.height)) > 0.12) continue;
                // Strong visual resemblance is mandatory; low-level facial texture
                // alone must never claim two different portraits are the same user.
                int fullImageDifference = Long.bitCount(a.visualHash ^ b.visualHash);
                if (fullImageDifference <= 12 && dot(a.faceFeature,b.faceFeature) >= 0.91) {
                    union(parent,i,j);
                }
            }
        }
        Map<Integer,List<PhotoInfo>> matched = new LinkedHashMap<>();
        for (int i=0; i<size; i++) matched.computeIfAbsent(root(parent,i),
                k -> new ArrayList<>()).add(suggestions.get(i));
        for (List<PhotoInfo> batch : matched.values()) {
            if (batch.size() < 2) {
                // A new standalone photo does not prove a new person exists.
                addUnclassified(batch.get(0));
                continue;
            }
            long key = batch.get(0).id;
            for (PhotoInfo p:batch) p.personGroup = key;
            people.computeIfAbsent(key,k -> new ArrayList<>()).addAll(batch);
        }
        // Display larger groups first, so the owner sees actual collections,
        // not hundreds of separate "person 1" buttons.
        List<Map.Entry<Long,List<PhotoInfo>>> entries=new ArrayList<>(people.entrySet());
        entries.sort((a,b)->Integer.compare(b.getValue().size(),a.getValue().size()));
        people.clear();
        for (Map.Entry<Long,List<PhotoInfo>> e:entries) people.put(e.getKey(),e.getValue());
    }

    private void groupSimilar() {
        List<PhotoInfo> sorted = new ArrayList<>();
        for (PhotoInfo p : all) if (p.analyzed) sorted.add(p);
        if (sorted.size() < 2) return;
        sorted.sort(Comparator.comparingLong(p -> p.taken));
        int n=sorted.size();
        int[] parent=new int[n];
        for (int i=0;i<n;i++) parent[i]=i;
        for (int i=0;i<n;i++) {
            PhotoInfo a=sorted.get(i);
            for (int j=i-1;j>=0 && i-j<=120;j--) {
                PhotoInfo b=sorted.get(j);
                if (a.taken-b.taken>180_000L) break;
                if (a.width>0 && a.height>0 && b.width>0 && b.height>0) {
                    double ratioA=(double)a.width/a.height, ratioB=(double)b.width/b.height;
                    if (Math.abs(ratioA-ratioB)>0.15) continue;
                }
                if (Long.bitCount(a.visualHash ^ b.visualHash)<=8) union(parent,i,j);
            }
        }
        Map<Integer,List<PhotoInfo>> found=new HashMap<>();
        for (int i=0;i<n;i++) found.computeIfAbsent(root(parent,i),k->new ArrayList<>()).add(sorted.get(i));
        List<List<PhotoInfo>> populated=new ArrayList<>();
        for (List<PhotoInfo> photos:found.values()) if (photos.size()>=2) populated.add(photos);
        populated.sort((a,b)->Long.compare(b.get(b.size()-1).taken,a.get(a.size()-1).taken));
        for (int i=0;i<populated.size();i++) {
            List<PhotoInfo> group=populated.get(i);
            group.sort((a,b)->Double.compare(b.sharpness,a.sharpness));
            similar.put(i,group);
            for (PhotoInfo p:group) p.similarGroup=i;
        }
    }

    private static int root(int[] parent,int i) {
        while (parent[i]!=i) {parent[i]=parent[parent[i]];i=parent[i];}
        return i;
    }
    private static void union(int[] parent,int a,int b) {
        int ra=root(parent,a),rb=root(parent,b);
        if (ra!=rb) parent[ra]=rb;
    }
}
