package com.dalkong.phototidy;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.Size;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.util.List;
import java.util.Locale;

/** Uses bundled ON-DEVICE models. Face features are a provisional texture heuristic,
 *  NOT an identity recognition model. Names/decisions must be verified by the owner. */
final class PhotoAnalyzer implements AutoCloseable {
    private final ContentResolver resolver;
    private final FaceDetector faceDetector;
    private final ImageLabeler labeler;

    PhotoAnalyzer(Context context) {
        resolver = context.getContentResolver();
        faceDetector = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setMinFaceSize(0.07f)
                .build());
        labeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(0.65f)
                .build());
    }

    boolean analyze(PhotoInfo photo) {
        if (photo.analyzed) return true;
        Bitmap bmp = null;
        try {
            bmp = resolver.loadThumbnail(photo.uri, new Size(960, 960), null);
            if (bmp == null || bmp.getWidth() < 8 || bmp.getHeight() < 8) {
                photo.analysisFailed = true;
                return false;
            }
            photo.visualHash = differenceHash(bmp);
            double[] quality = quality(bmp);
            photo.sharpness = quality[0];
            photo.brightness = quality[1];

            InputImage input = InputImage.fromBitmap(bmp, 0);
            List<Face> faces = Tasks.await(faceDetector.process(input));
            photo.faces = faces.size();
            if (faces.size() == 1) {
                Rect bounds = faces.get(0).getBoundingBox();
                photo.faceFeature = faceTexture(bmp, bounds);
            } else photo.faceFeature = null;

            List<ImageLabel> labels = Tasks.await(labeler.process(input));
            // Generic image labels are NOT dependable object detection.
            // A wedding dress/flowers can be mislabelled as an animal at 0.65.
            // Only strong dog/cat evidence on a photo with NO detected people
            // counts as an animal. Ambiguous images remain unclassified.
            photo.petConfidence = 0;
            for (ImageLabel label : labels) {
                String name = label.getText().toLowerCase(Locale.ROOT);
                if (name.equals("dog") || name.equals("cat")) {
                    photo.petConfidence = Math.max(photo.petConfidence, label.getConfidence());
                }
            }
            photo.pet = photo.faces == 0 && photo.petConfidence >= 0.94;

            // Conservative recommendations only. Never delete automatically.
            photo.deleteCandidate = false;
            photo.reason = "";
            if (photo.brightness < 18) {
                photo.deleteCandidate = true;
                photo.reason = "너무 어두운 사진 후보";
            } else if (photo.sharpness < 30 && photo.brightness > 45
                    && bmp.getWidth() >= 240 && bmp.getHeight() >= 240) {
                photo.deleteCandidate = true;
                photo.reason = "초점·흔들림 확인 후보";
            } else if (photo.width > 0 && photo.height > 0
                    && Math.min(photo.width, photo.height) < 180) {
                photo.deleteCandidate = true;
                photo.reason = "해상도가 낮은 사진 후보";
            }
            photo.analyzed = true;
            photo.analysisFailed = false;
            return true;
        } catch (Exception e) {
            photo.analysisFailed = true;
            android.util.Log.w("PhotoTidy", "Could not analyze " + photo.id, e);
            return false;
        } finally {
            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        }
    }

    /** dHash for near-duplicates; does not require online processing. */
    private static long differenceHash(Bitmap src) {
        Bitmap scaled = Bitmap.createScaledBitmap(src, 9, 8, true);
        long hash = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int a = gray(scaled.getPixel(x,y));
                int b = gray(scaled.getPixel(x + 1,y));
                hash = (hash << 1) | (a > b ? 1L : 0L);
            }
        }
        scaled.recycle();
        return hash;
    }

    /** Sample Laplacian variance + brightness. Values are heuristics, not an expert diagnosis. */
    private static double[] quality(Bitmap src) {
        Bitmap bmp = Bitmap.createScaledBitmap(src, 160, 160, true);
        int[] px = new int[160 * 160];
        bmp.getPixels(px, 0, 160, 0, 0, 160, 160);
        bmp.recycle();
        int[] gray = new int[px.length];
        double light = 0;
        for (int i = 0; i < px.length; i++) {
            gray[i] = gray(px[i]);
            light += gray[i];
        }
        double sum = 0, sq = 0;
        int count = 0;
        for (int y = 1; y < 159; y += 2) {
            for (int x = 1; x < 159; x += 2) {
                int i = y * 160 + x;
                int lap = 4 * gray[i] - gray[i-1] - gray[i+1] - gray[i-160] - gray[i+160];
                sum += lap; sq += (double) lap * lap; count++;
            }
        }
        return new double[]{Math.max(0, sq / count - Math.pow(sum / count, 2)), light / px.length};
    }

    private static int gray(int c) {
        return (Color.red(c)*30 + Color.green(c)*59 + Color.blue(c)*11)/100;
    }

    /** Lightweight local binary pattern descriptor of the face crop.
     *  Useful for suggesting groups, but it is NOT dependable identity recognition. */
    private static float[] faceTexture(Bitmap src, Rect r) {
        int padX = Math.round(r.width() * 0.08f);
        int padY = Math.round(r.height() * 0.08f);
        int left = Math.max(0, r.left - padX);
        int top = Math.max(0, r.top - padY);
        int right = Math.min(src.getWidth(), r.right + padX);
        int bottom = Math.min(src.getHeight(), r.bottom + padY);
        if (right - left < 35 || bottom - top < 35) return null;
        Bitmap crop = Bitmap.createBitmap(src, left, top, right-left, bottom-top);
        Bitmap small = Bitmap.createScaledBitmap(crop, 64, 64, true);
        crop.recycle();
        int[] px = new int[4096];
        small.getPixels(px,0,64,0,0,64,64);
        small.recycle();
        int[] g = new int[4096];
        for (int i = 0; i < g.length; i++) g[i] = gray(px[i]);
        float[] feature = new float[256]; // 4x4 cells * 16 coarse LBP bins
        int[] dx = {-1,0,1,1,1,0,-1,-1};
        int[] dy = {-1,-1,-1,0,1,1,1,0};
        for (int y = 1; y < 63; y++) {
            for (int x = 1; x < 63; x++) {
                int base = g[y*64+x];
                int pattern = 0;
                for (int k=0;k<8;k++) {
                    if (g[(y+dy[k])*64 + x+dx[k]] >= base) pattern |= (1<<k);
                }
                int cell = (Math.min(3,y/16) * 4 + Math.min(3,x/16));
                feature[cell*16 + (pattern >>> 4)]++;
            }
        }
        double norm=0;
        for (int i = 0; i < feature.length; i++) norm += feature[i]*feature[i];
        norm = Math.sqrt(norm);
        if (norm < 1) return null;
        for (int i = 0; i < feature.length; i++) feature[i] /= (float) norm;
        return feature;
    }

    @Override public void close() {
        faceDetector.close();
        labeler.close();
    }
}
