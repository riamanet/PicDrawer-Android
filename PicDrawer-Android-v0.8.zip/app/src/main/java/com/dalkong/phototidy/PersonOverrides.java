package com.dalkong.phototidy;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import java.util.List;
import java.util.Map;

/** Explicit user corrections take priority over provisional face-texture clustering.
 *  Stores only photo IDs, user-created groups and chosen names (not the images). */
final class PersonOverrides {
    private final File file;
    private final Map<Long,Long> assigned = new HashMap<>();
    private final Map<Long,String> names = new HashMap<>();
    private final Set<Long> unclassified = new HashSet<>();
    private long nextManual = -100;

    PersonOverrides(Context context) {
        file = new File(context.getFilesDir(), "person-corrections-v2.json");
        if (!file.exists()) return;
        try {
            JSONObject data = new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
            JSONObject a = data.optJSONObject("assignments");
            if (a != null) for (java.util.Iterator<String> it=a.keys(); it.hasNext();) {
                String key=it.next();
                try { assigned.put(Long.parseLong(key), a.getLong(key)); } catch (Exception ignored) { }
            }
            JSONObject n = data.optJSONObject("names");
            if (n != null) for (java.util.Iterator<String> it=n.keys(); it.hasNext();) {
                String key=it.next();
                try { names.put(Long.parseLong(key),n.getString(key)); } catch (Exception ignored) { }
            }
            JSONArray u = data.optJSONArray("unclassified");
            if (u != null) for (int i = 0; i < u.length(); i++) {
                long photoId = u.optLong(i, -1);
                if (photoId >= 0) unclassified.add(photoId);
            }
            for (long group:assigned.values()) if (group <= nextManual) nextManual=group-1;
            for (long group:names.keySet()) if (group <= nextManual) nextManual=group-1;
        } catch (Exception e) {
            Log.w("PhotoTidy", "Person corrections cannot be read",e);
        }
    }

    Long get(long photoId) { return assigned.get(photoId); }
    String name(long groupId) { return names.get(groupId); }

    boolean isUnclassified(long photoId) { return unclassified.contains(photoId); }

    void setUnclassified(long photoId, boolean value) {
        if (value) unclassified.add(photoId); else unclassified.remove(photoId);
        save();
    }

    long createGroup() { return nextManual--; }

    void pinGroup(long groupId,List<PhotoInfo> photos) {
        for (PhotoInfo photo:photos) assigned.put(photo.id,groupId);
        save();
    }

    void move(List<PhotoInfo> photos,long destination) {
        for (PhotoInfo photo:photos) assigned.put(photo.id,destination);
        save();
    }

    void rename(long group,String name) {
        if (name.trim().isEmpty()) return;
        names.put(group,name.trim());
        save();
    }

    private void save() {
        try {
            JSONObject data = new JSONObject(), a = new JSONObject(), n = new JSONObject();
            for (Map.Entry<Long,Long> item:assigned.entrySet()) a.put(String.valueOf(item.getKey()),item.getValue());
            for (Map.Entry<Long,String> item:names.entrySet()) n.put(String.valueOf(item.getKey()),item.getValue());
            JSONArray u = new JSONArray();
            for (long photoId : unclassified) u.put(photoId);
            data.put("unclassified", u);
            data.put("assignments",a);
            data.put("names",n);
            File temp=new File(file.getParentFile(),file.getName()+".tmp");
            Files.write(temp.toPath(),data.toString().getBytes(StandardCharsets.UTF_8));
            Files.move(temp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            Log.e("PhotoTidy", "Unable to save person corrections",e);
        }
    }
}
