package com.dalkong.phototidy;

import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class PhotoInfo {
    final long id;
    final Uri uri;
    final String bucketId;
    final String bucketName;
    final long modified;
    final long taken;
    final long bytes;
    final int width;
    final int height;

    boolean analyzed;
    int faces = -1;
    float[] faceFeature;
    boolean pet;
    long visualHash;
    double sharpness;
    double brightness;
    boolean deleteCandidate;
    String reason = "";
    long personGroup = -1;
    int similarGroup = -1;

    PhotoInfo(long id, Uri uri, String bucketId, String bucketName,
              long modified, long taken, long bytes, int width, int height) {
        this.id = id;
        this.uri = uri;
        this.bucketId = bucketId;
        this.bucketName = bucketName;
        this.modified = modified;
        this.taken = taken;
        this.bytes = bytes;
        this.width = width;
        this.height = height;
    }

    void restore(JSONObject j) {
        analyzed = j.optBoolean("analyzed", false);
        faces = j.optInt("faces", -1);
        pet = j.optBoolean("pet", false);
        visualHash = j.optLong("visualHash", 0);
        sharpness = j.optDouble("sharpness", 0);
        brightness = j.optDouble("brightness", 0);
        deleteCandidate = j.optBoolean("deleteCandidate", false);
        reason = j.optString("reason", "");
        JSONArray a = j.optJSONArray("faceFeature");
        if (a != null) {
            faceFeature = new float[a.length()];
            for (int i = 0; i < a.length(); i++) faceFeature[i] = (float) a.optDouble(i, 0);
        }
    }

    JSONObject save() throws JSONException {
        JSONObject j = new JSONObject();
        j.put("modified", modified);
        j.put("bytes", bytes);
        j.put("analyzed", analyzed);
        j.put("faces", faces);
        j.put("pet", pet);
        j.put("visualHash", visualHash);
        j.put("sharpness", sharpness);
        j.put("brightness", brightness);
        j.put("deleteCandidate", deleteCandidate);
        j.put("reason", reason);
        if (faceFeature != null) {
            JSONArray a = new JSONArray();
            for (float v : faceFeature) a.put((double) v);
            j.put("faceFeature", a);
        }
        return j;
    }
}
