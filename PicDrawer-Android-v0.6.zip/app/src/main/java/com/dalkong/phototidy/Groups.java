package com.dalkong.phototidy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Groups {
    final Map<Long,List<PhotoInfo>> people = new LinkedHashMap<>();
    final Map<Integer,List<PhotoInfo>> similar = new LinkedHashMap<>();
    final List<PhotoInfo> together = new ArrayList<>();
    final List<PhotoInfo> pets = new ArrayList<>();
    final List<PhotoInfo> candidates = new ArrayList<>();
    final List<PhotoInfo> others = new ArrayList<>();
    final List<PhotoInfo> all = new ArrayList<>();

    Groups(List<PhotoInfo> selected, PersonOverrides overrides) {
        for (PhotoInfo p : selected) {
            if (!p.analyzed) continue;
            all.add(p);
            p.personGroup = -1;
            p.similarGroup = -1;
            if (p.faces >= 2) together.add(p);
            if (p.pet) pets.add(p);
            if (p.deleteCandidate) candidates.add(p);
            if (p.faces == 0 || (p.faces == 1 && p.faceFeature == null)) others.add(p);
        }
        groupPeople(overrides);
        groupSimilar();
    }

    private static double dot(float[] a, float[] b) {
        if (a == null || b == null || a.length != b.length) return -1;
        double sum=0;
        for (int i=0;i<a.length;i++) sum += a[i]*b[i];
        return sum;
    }

    /** User-confirmed membership overrides all heuristics. Automatic groups are
     *  suggestions only; new photos cannot silently alter a manually corrected group. */
    private void groupPeople(PersonOverrides overrides) {
        List<float[]> prototypes = new ArrayList<>();
        List<Long> automaticGroups = new ArrayList<>();
        for (PhotoInfo p : all) {
            if (p.faces != 1) continue;
            Long fixed = overrides.get(p.id);
            if (fixed != null) {
                p.personGroup=fixed;
                people.computeIfAbsent(fixed, key->new ArrayList<>()).add(p);
                continue;
            }
            if (p.faceFeature == null) continue;
            double best=-1;
            int closest=-1;
            for (int i=0;i<prototypes.size();i++) {
                double score=dot(p.faceFeature,prototypes.get(i));
                if (score>best) {best=score;closest=i;}
            }
            long group;
            // Face texture is NOT a face recognition model. Prefer small,
            // conservative suggestion groups rather than confidently mixing people.
            if (closest>=0 && best>=0.970) group=automaticGroups.get(closest);
            else {
                group=p.id;
                prototypes.add(p.faceFeature.clone());
                automaticGroups.add(group);
            }
            p.personGroup=group;
            people.computeIfAbsent(group,k->new ArrayList<>()).add(p);
        }
    }

    private void groupSimilar() {
        if (all.size() < 2) return;
        List<PhotoInfo> sorted = new ArrayList<>(all);
        sorted.sort(Comparator.comparingLong(p -> p.taken));
        int n=sorted.size();
        int[] parent=new int[n];
        for (int i=0;i<n;i++) parent[i]=i;
        for (int i=0;i<n;i++) {
            PhotoInfo a=sorted.get(i);
            for (int j=i-1;j>=0 && i-j<=120;j--) {
                PhotoInfo b=sorted.get(j);
                if (a.taken-b.taken>180_000L) break;
                if (a.width>0 && a.height>0 && b.width>0 && b.height>0) {
                    double ratioA=(double)a.width/a.height, ratioB=(double)b.width/b.height;
                    if (Math.abs(ratioA-ratioB)>0.15) continue;
                }
                if (Long.bitCount(a.visualHash ^ b.visualHash)<=8) union(parent,i,j);
            }
        }
        Map<Integer,List<PhotoInfo>> found=new HashMap<>();
        for (int i=0;i<n;i++) found.computeIfAbsent(root(parent,i),k->new ArrayList<>()).add(sorted.get(i));
        List<List<PhotoInfo>> populated=new ArrayList<>();
        for (List<PhotoInfo> photos:found.values()) if (photos.size()>=2) populated.add(photos);
        populated.sort((a,b)->Long.compare(b.get(b.size()-1).taken,a.get(a.size()-1).taken));
        for (int i=0;i<populated.size();i++) {
            List<PhotoInfo> group=populated.get(i);
            group.sort((a,b)->Double.compare(b.sharpness,a.sharpness));
            similar.put(i,group);
            for (PhotoInfo p:group) p.similarGroup=i;
        }
    }

    private static int root(int[] parent,int i) {
        while (parent[i]!=i) {parent[i]=parent[parent[i]];i=parent[i];}
        return i;
    }
    private static void union(int[] parent,int a,int b) {
        int ra=root(parent,a),rb=root(parent,b);
        if (ra!=rb) parent[ra]=rb;
    }
}
