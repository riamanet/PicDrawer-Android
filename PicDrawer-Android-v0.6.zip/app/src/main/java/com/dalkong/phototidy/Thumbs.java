package com.dalkong.phototidy;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class Thumbs {
    private final Context context;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final LruCache<String,Bitmap> cache = new LruCache<String, Bitmap>(24*1024) {
        @Override protected int sizeOf(String k, Bitmap v) { return v.getByteCount()/1024; }
    };

    Thumbs(Context context) { this.context=context.getApplicationContext(); }

    void load(ImageView view, Uri uri, int size) {
        String key=uri.toString()+":"+size;
        view.setTag(key);
        Bitmap fromCache;
        synchronized(cache) { fromCache=cache.get(key); }
        if (fromCache != null && !fromCache.isRecycled()) {
            view.setImageBitmap(fromCache);
            return;
        }
        view.setImageDrawable(null);
        executor.execute(()-> {
            try {
                Bitmap bitmap=context.getContentResolver().loadThumbnail(uri,new Size(size,size),null);
                if (bitmap == null) return;
                synchronized(cache) { cache.put(key,bitmap); }
                view.post(()->{ if (key.equals(view.getTag())) view.setImageBitmap(bitmap); });
            } catch (Exception ignored) { }
        });
    }

    void shutdown() { executor.shutdownNow(); }
}
