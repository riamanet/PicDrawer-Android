package com.dalkong.phototidy;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class PhotoRepository {
    private final Context context;
    private final File cacheFile;
    private final Map<String, JSONObject> cached = new LinkedHashMap<>();

    PhotoRepository(Context context) {
        this.context = context.getApplicationContext();
        cacheFile = new File(context.getFilesDir(), "photo-analysis-v1.json");
        try {
            if (cacheFile.exists()) {
                JSONObject saved = new JSONObject(new String(Files.readAllBytes(cacheFile.toPath()), StandardCharsets.UTF_8));
                for (java.util.Iterator<String> it = saved.keys(); it.hasNext(); ) {
                    String key = it.next();
                    JSONObject value = saved.optJSONObject(key);
                    if (value != null) cached.put(key, value);
                }
            }
        } catch (Exception ignored) {
            cached.clear();
        }
    }

    List<PhotoInfo> getPhotos() {
        List<PhotoInfo> result = new ArrayList<>();
        Uri base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] columns = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.BUCKET_ID,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
        };
        try (Cursor c = context.getContentResolver().query(base, columns,
                null, null, MediaStore.Images.Media.DATE_TAKEN + " DESC")) {
            if (c == null) return result;
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String bucketId = c.getString(1);
                String bucketName = c.getString(2);
                long modified = c.getLong(3);
                long taken = c.isNull(4) ? modified * 1000 : c.getLong(4);
                long size = c.getLong(5);
                int width = c.getInt(6), height = c.getInt(7);
                PhotoInfo p = new PhotoInfo(id, ContentUris.withAppendedId(base, id),
                        bucketId == null ? "unknown" : bucketId,
                        bucketName == null ? "이름 없는 앨범" : bucketName,
                        modified, taken, size, width, height);
                JSONObject saved = cached.get(String.valueOf(id));
                if (saved != null && saved.optLong("modified", -1) == modified
                        && saved.optLong("bytes", -1) == size) p.restore(saved);
                result.add(p);
            }
        } catch (SecurityException e) {
            throw new IllegalStateException("사진 접근 권한이 필요합니다.", e);
        }
        return result;
    }

    Map<String, List<PhotoInfo>> albums(List<PhotoInfo> photos) {
        Map<String, List<PhotoInfo>> result = new LinkedHashMap<>();
        for (PhotoInfo p : photos) result.computeIfAbsent(p.bucketId, k -> new ArrayList<>()).add(p);
        List<Map.Entry<String, List<PhotoInfo>>> entries = new ArrayList<>(result.entrySet());
        entries.sort((a,b) -> Integer.compare(b.getValue().size(), a.getValue().size()));
        result.clear();
        for (Map.Entry<String, List<PhotoInfo>> entry : entries) result.put(entry.getKey(), entry.getValue());
        return result;
    }

    synchronized void saveCache(List<PhotoInfo> photos) {
        try {
            // Preserve results from other albums, too.
            for (PhotoInfo p : photos) {
                if (p.analyzed) cached.put(String.valueOf(p.id), p.save());
            }
            JSONObject all = new JSONObject();
            for (Map.Entry<String, JSONObject> entry : cached.entrySet())
                all.put(entry.getKey(), entry.getValue());
            File tmp = new File(context.getFilesDir(), "photo-analysis-v1.json.tmp");
            Files.write(tmp.toPath(), all.toString().getBytes(StandardCharsets.UTF_8));
            if (!tmp.renameTo(cacheFile)) {
                Files.move(tmp.toPath(), cacheFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) { }
    }
}
