# 픽서랍 v0.6 — APK 빌드 안내

현재 ZIP은 안드로이드 앱 **소스 프로젝트**입니다. `.apk` 파일은 포함되어 있지 않습니다.

## 휴대폰에서 GitHub를 통해 APK 만들기

기존에 GitHub 계정이 ChatGPT에 연결되어 있다면 다음처럼 진행할 수 있습니다.

1. 휴대폰 브라우저에서 https://github.com/new 페이지를 엽니다.
2. 저장소 이름을 `PicDrawer-Android`로 지정하고 **Private**으로 만듭니다.
   README / .gitignore / 라이선스는 생성하지 않아도 됩니다.
3. 생성한 저장소의 링크를 ChatGPT 대화에 보내주세요.
   기존 프로젝트 파일을 해당 저장소에 올리는 작업을 이어갈 수 있습니다.
4. 저장소에 이 프로젝트 소스와 `.github/workflows/build-apk.yml`이 올라가면
   **Actions → Build Android APK** 작업이 `main` 또는 `master` 브랜치 변경 시 자동 실행됩니다.
   또는 Actions에서 `Run workflow`를 누를 수 있습니다.
5. 작업이 **성공**으로 끝나면 해당 실행 화면의 **Artifacts**
   → `PicDrawer-v0.6-debug-apk`을 내려받아 압축을 풉니다.
   그 안의 `app-debug.apk`를 휴대폰에 설치할 수 있습니다.

**중요:** 앱 빌드가 실제 성공했는지는 Actions 로그를 확인해야 합니다.
지금 환경에서는 Android SDK와 Gradle 내려받기가 불가능하여
APK 생성 및 설치 테스트를 수행하지 못했습니다.

## Android Studio를 쓰는 경우

1. SDK 35 / JDK 17 / Gradle 8.9 환경에서 프로젝트를 엽니다.
2. Android Gradle Plugin 8.7.3이 사용할 수 있도록 Gradle 동기화를 완료합니다.
3. `gradle :app:assembleDebug`를 실행하면
   `app/build/outputs/apk/debug/app-debug.apk`에 설치용 파일이 생성됩니다.
4. 설치 후에는 반드시 **테스트용 사진 복사본**만 넣어 확인합니다.

## 주의 사항

- **실제 앱 설치 테스트 전**에는 중요한 사진이나 전체 앨범 대상으로 삭제 시험을 하지 마세요.
- 인물별 자동 분류는 사람 식별 인증 모델이 아닌 **후보 그룹**입니다.
- 삭제 추천은 단순 품질 지표를 사용합니다. 사진의 가치를 판정하지 않습니다.
- 사진 삭제는 앱 내부 선택 및 Android 시스템의 별도 승인 후에만 요청합니다.
- 현재 인터넷 권한은 없고 사진 데이터는 앱 내부에서 처리하도록 작성했습니다.
- `app-debug.apk`는 테스트용으로 자동 서명되며 Play 스토어 출시용 파일이 아닙니다.
